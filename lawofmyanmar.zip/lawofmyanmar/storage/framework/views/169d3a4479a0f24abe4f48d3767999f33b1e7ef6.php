
<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<div class="add">
			<h1>court </h1>
			<form action="<?php echo e(route('court.store')); ?>" method="post" enctype="multipart/form-data">
				<?php echo csrf_field(); ?>
				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Court Name</label>
				</div>
				<div class="col-md-5">
					<input type="text" name="name" class="form-control">
				</div>
				
				</div>
				
				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Address</label>
				</div>
				<div class="col-md-5">
					<input type="text" name="address" class="form-control">
				</div>
				
				</div>
				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Phone</label>
				</div>
				<div class="col-md-5">
					<input type="text" name="phone" class="form-control">
				</div>
				
				</div>

				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Lat</label>
					</div>
					<div class="col-md-5">
						<input type="text" name="lat" class="form-control">
					</div>
				
				</div>

				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Long</label>
				</div>
				<div class="col-md-5">
					<input type="text" name="long" class="form-control">
				</div>
				
				</div>
				
				
				<div class="col-md-3">
					<input type="submit" value="ADD">
				</div>
			</form>	
		</div>
		<div class="edit">
			<h1> Edit court </h1>
			<form action="<?php echo e(route('court.update',1)); ?>" method="post" enctype="multipart/form-data">
				<?php echo csrf_field(); ?>
				<?php echo method_field('PUT'); ?>
				<input type="hidden" name="edit_id" id="edit_id">
				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>court Name</label>
				</div>
				<div class="col-md-5">
					<input type="text" name="edit_name" class="form-control" id="edit_name">
				</div>
				
				</div>
				
				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Address</label>
				</div>
				<div class="col-md-5">
					<input type="text" name="edit_address" class="form-control" id="edit_address">
				</div>
				
				</div>
				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Phone</label>
				</div>
				<div class="col-md-5">
					<input type="text" name="edit_phone" class="form-control" id="edit_phone">
					
				</div>
				
				</div>

				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Lat</label>
				</div>
				<div class="col-md-5">
					<input type="number" name="edit_lat" class="form-control" id="edit_lat">
				</div>
				
				</div>

				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Long</label>
				</div>
				<div class="col-md-5">
					<input type="number" name="edit_long" class="form-control" id="edit_long">
				</div>
				
				</div>
				
				
				<div class="col-md-3">
					<input type="submit" value="Update">
				</div>
			</form>	
		</div>

		

	<div class="col-md-8 offset-2 mt-5">

		<table class="table table-dark table-sm">
			<tr>
				<th>NO.</th>
				<th>Court Name</th>
				<th>Phone</th>
				<th>Address</th>
				<th>lat</th>
				<th>long</th>
				<th colspan="2">Action</th>
			</tr>
			<?php $i = 1; ?>
			<?php $__currentLoopData = $courts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $court): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($i++); ?></td>
				<td><?php echo e($court->name); ?></td>
				<td><?php echo e($court->phone); ?></td>
				<td><?php echo e($court->address); ?></td>
				<td><?php echo e($court->lat); ?></td>
				<td><?php echo e($court->lng); ?></td>
				<td>
					<a href="#" class="btn btn-secondary  edit_item " data-id="<?php echo e($court->id); ?>" data-name = "<?php echo e($court->name); ?>" data-address="<?php echo e($court->address); ?>" data-phone="<?php echo e($court->phone); ?>"  data-lat= "<?php echo e($court->lat); ?>" data-lng="<?php echo e($court->lng); ?>" >Edit</a>
				</td>
				<td>	
                    <form action="<?php echo e(route('court.destroy',$court->id)); ?>" method="post">
                        <?php echo method_field('Delete'); ?>
                        <?php echo csrf_field(); ?>
                        <input type="submit" name="btnsubmit" value="Delete" class="btn btn-danger">
                     </form>
                </td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>
	</div>
		
	</div>
	
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

	<script type="text/javascript">
		
		$(document).ready(function(){
			$('.add').show();
			$('.edit').hide();
			$('.edit_item').click(function(){
				$('.edit').show();
				$('.add').hide();
				var id = $(this).data('id');
				var name = $(this).data('name');
				var phone = $(this).data('phone');
				var address = $(this).data('address');
				var lat = $(this).data('lat');
				var lng = $(this).data('lng');
				console.log(id,name,address,phone);
				$('#edit_id').val(id);
				$('#edit_name').val(name);
				$('#edit_address').val(address);
				$('#edit_phone').val(phone);
				$('#edit_lat').val(lat);
				$('#edit_long').val(lng);
			})
		})
	</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backtemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lawofmyanmar\resources\views/court/index.blade.php ENDPATH**/ ?>