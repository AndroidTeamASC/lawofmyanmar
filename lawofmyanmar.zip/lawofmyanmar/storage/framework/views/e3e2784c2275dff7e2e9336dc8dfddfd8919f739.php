
<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<div class="add">
			<h1>Chapter </h1>
			<form action="<?php echo e(route('chapter.store')); ?>" method="post" enctype="multipart/form-data">
				<?php echo csrf_field(); ?>

				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Chapter No</label>
				</div>
				<div class="col-md-5">
					<input type="text" name="chapter_no" class="form-control">
				</div>

				</div>

				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Section</label>
				</div>
				<div class="col-md-5">
					<input type="text" name="section" class="form-control">
				</div>

				</div>

				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Law</label>
				</div>
				<div class="col-md-5">
					<select name="law_id" class="form-control">
						<option selected disabled>Select Law</option>
						<?php $__currentLoopData = $laws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $law): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($law->id); ?>"><?php echo e($law->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
				
				</div>
				
				
				
				<div class="col-md-2">
					<input type="submit" value="ADD">
				</div>	
			</form>	
		</div>
		<div class="edit">
			<h1> Edit chapter </h1>
			<form action="<?php echo e(route('chapter.update',1)); ?>" method="post" enctype="multipart/form-data">
				<?php echo csrf_field(); ?>
				<?php echo method_field('PUT'); ?>
				<input type="hidden" name="edit_id" id="edit_id">
				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Chapter No</label>
				</div>
				<div class="col-md-5">
					<input type="text" name="edit_chapter_no" class="form-control" id="edit_chapter_no">
				</div>

				</div>

				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Section</label>
				</div>
				<div class="col-md-5">
					<input type="text" name="edit_section" class="form-control" id="edit_section">
				</div>

				</div>

				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Law</label>
				</div>
				<div class="col-md-5">
					<select name="edit_law_id" class="form-control" id="edit_law_id">
						<option selected disabled>Select Law</option>
						<?php $__currentLoopData = $laws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $law): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($law->id); ?>"><?php echo e($law->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
				
				</div>
				
				
				
				<div class="col-md-2">
					<input type="submit" value="Update">
				</div>

				
			</form>	
		</div>

		

	<div class="col-md-10 mt-5">

		<table class="table table-dark table-sm">
			<tr>
				<th>NO.</th>
				<th>chapter No</th>
				<th>law</th>
				<th>Section</th>
				<th colspan="2">Action</th>
			</tr>
			<?php $i = 1; ?>
			<?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($i++); ?></td>
				<td><?php echo e($chapter->chapter_no); ?></td>
				<td><?php echo e($chapter->law->name); ?></td>
				<td><?php echo e($chapter->section); ?></td>
				<td>
					<a href="#" class="btn btn-secondary  edit_item " data-id="<?php echo e($chapter->id); ?>" data-chapter_no = "<?php echo e($chapter->chapter_no); ?>" data-law_id="<?php echo e($chapter->law_id); ?>" data-section="section">Edit</a>
				</td>
				<td>	
                    <form action="<?php echo e(route('chapter.destroy',$chapter->id)); ?>" method="post">
                        <?php echo method_field('Delete'); ?>
                        <?php echo csrf_field(); ?>
                        <input type="submit" name="btnsubmit" value="Delete" class="btn btn-danger">
                     </form>
                </td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>
	</div>
		
	</div>
	
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

	<script type="text/javascript">
		
		$(document).ready(function(){
			$('.add').show();
			$('.edit').hide();
			$('.edit_item').click(function(){
				$('.edit').show();
				$('.add').hide();
				var id = $(this).data('id');
				var chapter_no = $(this).data('chapter_no');
				var law_id     = $(this).data('law_id');
				var section    = $(this).data('section');

				
				console.log(id,chapter_no,law_id);
				$('#edit_id').val(id);
				$('#edit_chapter_no').val(chapter_no);
				$('#edit_section').val(section);
				$('#edit_law_id').val(law_id);
				
			})
		})
	</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backtemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lawofmyanmar\resources\views/chapter/index.blade.php ENDPATH**/ ?>