
<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-12">
		<div class="add">
			<h1>Law </h1>
			<form action="<?php echo e(route('law.store')); ?>" method="post" enctype="multipart/form-data">
				<?php echo csrf_field(); ?>
				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>law Name</label>
				</div>
				<div class="col-md-5">
					<input type="text" name="name" class="form-control">
				</div>
				
				</div>
				
				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Type</label>
				</div>
				<div class="col-md-5">
					<input type="text" name="type" class="form-control">
				</div>
				
				</div>
				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Law Number</label>
				</div>
				<div class="col-md-5">
					<input type="text" name="law_no" class="form-control">
				</div>
				
				</div>
				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>main</label>
				</div>
				<div class="col-md-5">
					<input type="text" name="main" class="form-control">
				</div>
				
				</div>

				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Publishded Date</label>
				</div>
				<div class="col-md-5">
					<input type="date" name="published_date" class="form-control">
				</div>
				
				</div>

				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Release Date</label>
				</div>
				<div class="col-md-5">
					<input type="date" name="release_date" class="form-control">
				</div>
				
				</div>

				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Department</label>
				</div>
				<div class="col-md-5">
					<select name="department" class="form-control">
						<option selected disabled>Select Department</option>
						<?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($department->id); ?>"><?php echo e($department->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
				
				</div>

				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Law type</label>
				</div>
				<div class="col-md-5">
					<select name="law_type" class="form-control">
						<option selected disabled>Select Law Type</option>
						<?php $__currentLoopData = $law_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $law_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($law_type->id); ?>"><?php echo e($law_type->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
				
				</div>

				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Region</label>
				</div>
				<div class="col-md-5">
					<select name="region" class="form-control">
						<option selected disabled>Select Region</option>
						<?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($region->id); ?>"><?php echo e($region->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
				
				</div>
				

				
				
				<div class="col-md-3">
					<input type="submit" value="ADD">
				</div>
			</form>	
		</div>
		<div class="edit">
			<h1> Edit Law </h1>
			<form action="<?php echo e(route('law.update',1)); ?>" method="post" enctype="multipart/form-data">
				<?php echo csrf_field(); ?>
				<?php echo method_field('PUT'); ?>
				<input type="hidden" name="edit_id" id="edit_id">
				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>law Name</label>
				</div>
				<div class="col-md-5">
					<input type="text" name="edit_name" class="form-control" id="edit_name">
				</div>
				
				</div>
				
				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Type</label>
				</div>
				<div class="col-md-5">
					<input type="text" name="edit_type" class="form-control" id="edit_type">
				</div>
				
				</div>
				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Law Number</label>
				</div>
				<div class="col-md-5">
					<input type="text" name="law_no" class="form-control" id="edit_law_no">
				</div>
				
				</div>
				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>main</label>
				</div>
				<div class="col-md-5">
					<input type="text" name="edit_main" class="form-control" id="edit_main">
				</div>
				
				</div>

				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Publishded Date</label>
				</div>
				<div class="col-md-5">
					<input type="date" name="edit_published_date" class="form-control" id="edit_published_date">
				</div>
				
				</div>

				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Release Date</label>
				</div>
				<div class="col-md-5">
					<input type="date" name="edit_release_date" class="form-control" id="edit_release_date">
				</div>
				
				</div>

				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Department</label>
				</div>
				<div class="col-md-5">
					<select name="edit_department_id" id="edit_department_id">
						<option selected disabled>Select Department</option>
						<?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($department->id); ?>"><?php echo e($department->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
				
				</div>

				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Law type</label>
				</div>
				<div class="col-md-5">
					<select name="edit_law_type_id" id="edit_law_type_id">
						<option selected disabled>Select Law Type</option>
						<?php $__currentLoopData = $law_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $law_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($law_type->id); ?>"><?php echo e($law_type->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
				
				</div>

				<div class="row mt-5">
					<div class="col-md-3 ">
					<label>Region</label>
				</div>
				<div class="col-md-5">
					<select name="edit_region" id="edit_region">
						<option selected disabled>Select Region</option>
						<?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($region->id); ?>"><?php echo e($region->name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
				
				</div>
				

				
				
				<div class="col-md-3">
					<input type="submit" value="Update">
				</div>
			</form>	
		</div>

		

	<div class="col-md-10 mt-5">

		<table class="table table-dark table-sm">
			<tr>
				<th>NO.</th>
				<th>law Name</th>
				<th>Type</th>
				<th>main</th>
				<th>Published Date</th>
				<th>Release Date</th>
				<th colspan="2">Action</th>
			</tr>
			<?php $i = 1; ?>
			<?php $__currentLoopData = $laws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $law): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($i++); ?></td>
				<td><?php echo e($law->name); ?></td>
				<td><?php echo e($law->type); ?></td>
				<td><?php echo e($law->main); ?></td>
				<td><?php echo e($law->published_date); ?></td>
				<td><?php echo e($law->release_date); ?></td>
				<td>
					<a href="#" class="btn btn-secondary  edit_item " data-id="<?php echo e($law->id); ?>" data-name = "<?php echo e($law->name); ?>" data-type="<?php echo e($law->type); ?>" data-main="<?php echo e($law->main); ?>"  data-published_date="<?php echo e($law->published_date); ?>" data-release_date="<?php echo e($law->release_date); ?>" data-department_id="<?php echo e($law->department_id); ?>" data-law_type_id="<?php echo e($law->law_type_id); ?>" data-region_id = "<?php echo e($law->region_id); ?>" 
						data-Law_no="<?php echo e($law->law_no); ?>">Edit</a>
				</td>
				<td>	
                    <form action="<?php echo e(route('law.destroy',$law->id)); ?>" method="post">
                        <?php echo method_field('Delete'); ?>
                        <?php echo csrf_field(); ?>
                        <input type="submit" name="btnsubmit" value="Delete" class="btn btn-danger">
                     </form>
                </td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</table>
	</div>
		
	</div>
	
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

	<script type="text/javascript">
		
		$(document).ready(function(){
			$('.add').show();
			$('.edit').hide();
			$('.edit_item').click(function(){
				$('.edit').show();
				$('.add').hide();
				var id = $(this).data('id');
				var name = $(this).data('name');
				var type = $(this).data('type');
				var main = $(this).data('main');
				var published_date = $(this).data('published_date');
				var release_date = $(this).data('release_date');
				var department_id = $(this).data('department_id');
				var law_type_id = $(this).data('law_type_id');
				var region_id = $(this).data('region_id');
				var law_no = $(this).data('law_no')
				console.log(id,name,department_id);
				$('#edit_id').val(id);
				$('#edit_name').val(name);
				$('#edit_type').val(type);
				$('#edit_main').val(main);
				$('#edit_published_date').val(published_date);
				$('#edit_release_date').val(release_date);
				$('#edit_department_id').val(department_id);
				$('#edit_law_type_id').val(law_type_id);
				$('#edit_region_id').val(region_id);
				$('#edit_law_no')
			})
		})
	</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backtemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lawofmyanmar\resources\views/law/index.blade.php ENDPATH**/ ?>