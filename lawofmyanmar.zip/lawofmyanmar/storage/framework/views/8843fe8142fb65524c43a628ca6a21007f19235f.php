<ul class="sidebar navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="/head/dashboard">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
      </li>
		<li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('department.index')); ?>">
          <i class="fas fa-fw fa-table"></i>
          <span>Department</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('court.index')); ?>">
          <i class="fas fa-fw fa-table"></i>
          <span>Court</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('lawyer.index')); ?>">
          <i class="fas fa-fw fa-table"></i>
          <span>Lawyer</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('region.index')); ?>">
          <i class="fas fa-fw fa-table"></i>
          <span>Region</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('law.index')); ?>">
          <i class="fas fa-fw fa-table"></i>
          <span>Law</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('chapter.index')); ?>">
          <i class="fas fa-fw fa-table"></i>
          <span>Chapter</span></a>
    </li>      

    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('detail.index')); ?>">
          <i class="fas fa-fw fa-table"></i>
          <span>Detail</span></a>
    </li> 
      
    </ul>
<?php /**PATH C:\xampp\htdocs\lawofmyanmar\resources\views/sidebar.blade.php ENDPATH**/ ?>