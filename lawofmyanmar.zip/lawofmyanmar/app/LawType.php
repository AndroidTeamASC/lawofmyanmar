<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LawType extends Model
{
    protected $fillable = ['name'];
}
